
import mongoose from "mongoose";

const RepairPhotoSchema = new mongoose.Schema(
  {
    url: { type: String, required: true },
    publicId: { type: String, default: null },
    note: { type: String, default: "" },
    uploadedAt: { type: Date, default: Date.now },
  },
  { _id: true }
);

const StatusHistorySchema = new mongoose.Schema(
  {
    status: {
      type: String,
      enum: ["Reported", "Assigned", "In Progress", "Repaired", "Verified"],
      required: true,
    },
    note: { type: String, default: "" },
    changedBy: { type: String, default: "System" },
    changedAt: { type: Date, default: Date.now },
  },
  { _id: false }
);

const ReportSchema = new mongoose.Schema(
  {
    id: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },

    image: String,
    imageUrl: String,
    mediaUrl: String,
    cloudinaryPublicId: String,
    resourceType: String,
    localImageUrl: String,
    originalName: String,

    location: {
      latitude: { type: Number, default: null },
      longitude: { type: Number, default: null },
      source: { type: String, default: null },
    },
    latitude: { type: Number, default: null },
    longitude: { type: Number, default: null },

    detections: {
      type: [mongoose.Schema.Types.Mixed],
      default: [],
    },
    detectionCount: { type: Number, default: 0 },
    framesAnalyzed: { type: Number, default: 0 },

    severity: {
      type: String,
      enum: ["Critical", "High", "Medium", "Low", "None"],
      default: "None",
    },
    priorityScore: { type: Number, default: 0, index: true },

    // Open remains supported for existing reports.
    repairStatus: {
      type: String,
      enum: [
        "Open",
        "Reported",
        "Assigned",
        "In Progress",
        "Repaired",
        "Verified",
      ],
      default: "Reported",
      index: true,
    },

    assignedTeam: { type: String, default: "" },
    repairNotes: { type: String, default: "" },

    statusHistory: {
      type: [StatusHistorySchema],
      default: [],
    },

    beforeRepairPhotos: {
      type: [RepairPhotoSchema],
      default: [],
    },
    afterRepairPhotos: {
      type: [RepairPhotoSchema],
      default: [],
    },

    repairedAt: { type: Date, default: null },
    verifiedAt: { type: Date, default: null },

    mode: String,
    isSimulated: { type: Boolean, default: false },
  },
  { timestamps: true }
);

ReportSchema.index({ priorityScore: -1, createdAt: -1 });
ReportSchema.index({ repairStatus: 1, severity: 1 });

export default mongoose.model("Report", ReportSchema);
