
import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:5000/api",
  timeout: 180000,
});

export async function checkBackend() {
  try {
    const response = await api.get("/health");
    return response.data;
  } catch (error) {
    throw new Error(
      error.response?.data?.message || "Backend is not reachable."
    );
  }
}

export async function analyzeRoadImage({ image, latitude, longitude }) {
  const formData = new FormData();
  formData.append("image", image);

  if (latitude !== "" && longitude !== "") {
    formData.append("latitude", String(latitude));
    formData.append("longitude", String(longitude));
  }

  try {
    const response = await api.post("/analyze", formData);
    return response.data;
  } catch (error) {
    throw new Error(
      error.response?.data?.message ||
      error.response?.data?.error ||
      error.message ||
      "Image analysis failed."
    );
  }
}

export async function analyzeRoadVideo({ video, latitude, longitude }) {
  const formData = new FormData();
  formData.append("video", video);

  if (latitude !== "" && longitude !== "") {
    formData.append("latitude", String(latitude));
    formData.append("longitude", String(longitude));
  }

  try {
    const response = await api.post("/analyze-video", formData);
    return response.data;
  } catch (error) {
    throw new Error(
      error.response?.data?.message ||
      error.response?.data?.error ||
      error.message ||
      "Video analysis failed."
    );
  }
}

export async function fetchReports() {
  const response = await api.get("/reports");
  return response.data;
}

export async function updateReportStatus(id, data) {
  try {
    const response = await api.patch(
      `/reports/${encodeURIComponent(id)}/status`,
      data
    );
    return response.data;
  } catch (error) {
    throw new Error(
      error.response?.data?.message ||
      error.response?.data?.error ||
      error.message ||
      "Could not update repair workflow."
    );
  }
}

export default api;
