import { randomUUID } from "node:crypto";
import { extractVideoFrames } from "../services/videoFrameService.js";
import fs from "node:fs/promises";
import { detectRoadDamage, detectRoadDamageInFrames } from "../services/detectionService.js";
import {
  extractImageLocation,
  parseManualLocation,
} from "../services/location.js";
import Report from "../models/Report.js";
const reports = [];

export async function analyzeImage(req, res, next) {
  if (!req.file) {
    return res.status(400).json({
      success: false,
      message: "Upload a road image using the 'image' field.",
    });
  }

  try {
    const manualLocation = parseManualLocation(
      req.body.latitude,
      req.body.longitude
    );

    // Prefer coordinates explicitly supplied by the user/browser.
    const location =
      manualLocation || (await extractImageLocation(req.file.path));

    const analysis = await detectRoadDamage(req.file);

    const report = {
      id: randomUUID(),
      image: req.file.filename,
      imageUrl: `/uploads/${req.file.filename}`,
      originalName: req.file.originalname,
      createdAt: new Date().toISOString(),
      location,
      detections: analysis.detections,
      mode: analysis.mode,
      isSimulated: analysis.isSimulated,
    };

    reports.unshift(report);

    return res.status(201).json({
      success: true,
      message: analysis.isSimulated
        ? "Image uploaded. Demo detections are simulated, not AI predictions."
        : "Image analyzed by the connected AI service.",
      report,
    });
  } catch (error) {
    // Invalid coordinates or detection failure should not leave
    // an untracked uploaded file behind.
    await fs.unlink(req.file.path).catch(() => {});
    next(error);
  }
}

export function listReports(req, res) {
  return res.json({
    success: true,
    count: reports.length,
    reports,
  });
}

export function getReportById(req, res) {
  const report = reports.find((item) => item.id === req.params.id);

  if (!report) {
    return res.status(404).json({
      success: false,
      message: "Report not found.",
    });
  }

  return res.json({
    success: true,
    report,
  });
}
export async function analyzeVideo(req, res, next) {
  if (!req.file) {
    return res.status(400).json({
      success: false,
      message: "Upload a road video using the 'video' field.",
    });
  }

  let frameDirectory;

  try {
    const location = parseManualLocation(
      req.body.latitude,
      req.body.longitude
    );

    const extracted = await extractVideoFrames(req.file.path);
    frameDirectory = extracted.directory;

    const analysis = await detectRoadDamageInFrames(extracted.frames);

    const report = {
      id: randomUUID(),
      image: req.file.filename,
      imageUrl: `/uploads/${req.file.filename}`,
      originalName: req.file.originalname,
      createdAt: new Date().toISOString(),
      location,
      detections: analysis.detections,
      detectionCount: analysis.detections.length,
      framesAnalyzed: analysis.framesAnalyzed,
      mode: analysis.mode,
      isSimulated: analysis.isSimulated,
      mediaType: "video",
    };

    reports.unshift(report);

    return res.status(201).json({
      success: true,
      message: analysis.isSimulated
        ? "Video processed using demo detections."
        : "Video frames analyzed by the connected AI service.",
      report,
    });
  } catch (error) {
    await fs.unlink(req.file.path).catch(() => {});
    return next(error);
  } finally {
    if (frameDirectory) {
      await fs.rm(frameDirectory, {
        recursive: true,
        force: true,
      }).catch(() => {});
    }
  }
}

export async function updateReportStatus(req, res, next) {
  try {
    const { repairStatus, assignedTeam, repairNotes, changedBy } = req.body;

    const allowedStatuses = [
      "Reported", "Assigned", "In Progress", "Repaired", "Verified"
    ];

    if (!allowedStatuses.includes(repairStatus)) {
      return res.status(400).json({
        success: false,
        message: "Invalid repair status."
      });
    }

    // Reports currently held in the active in-memory analysis session
    const report = reports.find((item) => item.id === req.params.id);

    if (report) {
      const current = report.repairStatus === "Open"
        ? "Reported"
        : (report.repairStatus || "Reported");

      const transitions = {
        Reported: ["Reported", "Assigned"],
        Assigned: ["Assigned", "In Progress", "Reported"],
        "In Progress": ["In Progress", "Assigned", "Repaired"],
        Repaired: ["Repaired", "In Progress", "Verified"],
        Verified: ["Verified", "In Progress"]
      };

      if (!transitions[current]?.includes(repairStatus)) {
        return res.status(400).json({
          success: false,
          message: `Cannot change status from ${current} to ${repairStatus}.`
        });
      }

      if (repairStatus === "Assigned" &&
          !String(assignedTeam ?? report.assignedTeam ?? "").trim()) {
        return res.status(400).json({
          success: false,
          message: "Enter the responsible team before assigning."
        });
      }

      if (repairStatus === "Verified" && current !== "Repaired") {
        return res.status(400).json({
          success: false,
          message: "Repair must be completed before verification."
        });
      }

      report.repairStatus = repairStatus;
      report.assignedTeam = String(
        assignedTeam ?? report.assignedTeam ?? ""
      ).trim();
      report.repairNotes = String(
        repairNotes ?? report.repairNotes ?? ""
      ).trim();

      report.statusHistory ??= [];
      if (current !== repairStatus) {
        report.statusHistory.push({
          status: repairStatus,
          note: report.repairNotes,
          changedBy: String(changedBy || "Field Team"),
          changedAt: new Date().toISOString()
        });
      }

      if (repairStatus === "Repaired") {
        report.repairedAt ??= new Date().toISOString();
      }
      if (repairStatus === "Verified") {
        report.verifiedAt ??= new Date().toISOString();
      }

      return res.json({
        success: true,
        message: "Repair workflow updated.",
        report
      });
    }

    // Fallback: reports stored in MongoDB
    const dbReport = await Report.findOne({ id: req.params.id });

    if (!dbReport) {
      return res.status(404).json({
        success: false,
        message: "Report not found. Refresh the reports list and try again."
      });
    }

    const current = dbReport.repairStatus === "Open"
      ? "Reported"
      : dbReport.repairStatus;

    const transitions = {
      Reported: ["Reported", "Assigned"],
      Assigned: ["Assigned", "In Progress", "Reported"],
      "In Progress": ["In Progress", "Assigned", "Repaired"],
      Repaired: ["Repaired", "In Progress", "Verified"],
      Verified: ["Verified", "In Progress"]
    };

    if (!transitions[current]?.includes(repairStatus)) {
      return res.status(400).json({
        success: false,
        message: `Cannot change status from ${current} to ${repairStatus}.`
      });
    }

    if (repairStatus === "Assigned" &&
        !String(assignedTeam ?? dbReport.assignedTeam ?? "").trim()) {
      return res.status(400).json({
        success: false,
        message: "Enter the responsible team before assigning."
      });
    }

    if (repairStatus === "Verified" && current !== "Repaired") {
      return res.status(400).json({
        success: false,
        message: "Repair must be completed before verification."
      });
    }

    if (assignedTeam !== undefined) {
      dbReport.assignedTeam = String(assignedTeam).trim();
    }
    if (repairNotes !== undefined) {
      dbReport.repairNotes = String(repairNotes).trim();
    }

    dbReport.repairStatus = repairStatus;

    if (current !== repairStatus) {
      dbReport.statusHistory.push({
        status: repairStatus,
        note: String(repairNotes || ""),
        changedBy: String(changedBy || "Field Team")
      });
    }

    if (repairStatus === "Repaired") {
      dbReport.repairedAt ??= new Date();
    }
    if (repairStatus === "Verified") {
      dbReport.verifiedAt ??= new Date();
    }

    await dbReport.save();

    return res.json({
      success: true,
      message: "Repair workflow saved to MongoDB.",
      report: dbReport
    });
  } catch (error) {
    next(error);
  }
}


export async function uploadRepairPhoto(req, res, next) {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: "Please select a repair photo.",
      });
    }

    const { type, note } = req.body;

    if (!["before", "after"].includes(type)) {
      await fs.unlink(req.file.path).catch(() => {});
      return res.status(400).json({
        success: false,
        message: "Photo type must be before or after.",
      });
    }

    const photo = {
      url: `/uploads/repairs/${req.file.filename}`,
      note: String(note || "").trim(),
      uploadedAt: new Date(),
    };

    // First check reports in the current backend session.
    let report = reports.find((item) => item.id === req.params.id);

    if (report) {
      const field =
        type === "before" ? "beforeRepairPhotos" : "afterRepairPhotos";

      report[field] ??= [];
      report[field].push(photo);

      return res.status(201).json({
        success: true,
        message: `${type === "before" ? "Before" : "After"} repair photo uploaded.`,
        report,
        photo,
      });
    }

    // If not in memory, check MongoDB.
    const dbReport = await Report.findOne({ id: req.params.id });

    if (!dbReport) {
      await fs.unlink(req.file.path).catch(() => {});
      return res.status(404).json({
        success: false,
        message: "Report not found.",
      });
    }

    const field =
      type === "before" ? "beforeRepairPhotos" : "afterRepairPhotos";

    if (!Array.isArray(dbReport[field])) {
      dbReport[field] = [];
    }

    dbReport[field].push(photo);
    await dbReport.save();

    return res.status(201).json({
      success: true,
      message: `${type === "before" ? "Before" : "After"} repair photo saved.`,
      report: dbReport,
      photo,
    });
  } catch (error) {
    next(error);
  }
}

